class RoutesManager {
  static const String splashRoute = '/splash';
  static const String homeRoute = 'home';
  static const String loginRoute = 'login';
  static const String createRoute = 'create';
  static const String detailsRoute = 'details';
  static const String chatRoute = 'chat';
}
